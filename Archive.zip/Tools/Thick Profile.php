<body>
	<div id="background">
		<article>
			<h1>Translation</h1>
			<p>
				<b>The ‘thick’ option in general creates a boundary around the sketch you have drawn to perform a task, providing a shortcut when doing certain operations</b>
				<br></br>
				Firstly create a sketch that can be padded easily
				<br>
				<img class="tools_image" src="Tools\Tools_Images\Thick Profile\Thick-Profile-1.png" ;>
				<br></br>
				When padding, click on the box next to ‘Thick’ to create a thick profile
				<br>
				<img class="tools_image" src="Tools\Tools_Images\Thick Profile\Thick-Profile-2.png" ;>
				<br>
				<img class="tools_image" src="Tools\Tools_Images\Thick Profile\Thick-Profile-3.png" ;>
				<br></br>
				Enter the dimensions for the wall thickness, press ok and or preview to see the tick profile in effect. You have now created a thick profile profiled object.
				<br>
				<img class="tools_image" src="Tools\Tools_Images\Thick Profile\Thick-Profile-4.png" ;>
				<br>
			</p>
	</article>
	</div>
</body>
</html>
