<html>

<head>
	<title> Porticast: Catia Home</title>
	<link rel="stylesheet" type = "text/css" href="style.css?version=1"  />
</head>

<body>
	<header>
		<div id="banner">
			<img src="Banner2.png" alt="error" width=100%/>
			<a id="UCLHome" href="https://www.ucl.ac.uk" target="_blank"></a>
		</div>

		<nav>
			<ul>
				<li>
					<a href="index.php"> Home </a>
				</li>
				<li>	
					<a class="selected" href="#"> Catia </a> 
					<ul>
						<li><a class="selected" href="Catia-Home.php">Home</a></li>
						<li><a href="">FAQ</a></li>
						<li><a href="">Forum</a></li>
						<li><a href="Catia-Quiz.php">Quiz</a></li>
					</ul> 
				</li>	
				<li>
					<a href="Wicklow-Home.php"> Wicklow Street Induction </a>
				</li>
				<li>
					<a href="Matlab-Home.php"> Matlab </a>
				</li>
				<li>
					<a href="Forum-Home.php"> Forum </a>
				</li>
			</ul>
		</nav>
	</header>

<footer>
</footer>
</body>

</html>