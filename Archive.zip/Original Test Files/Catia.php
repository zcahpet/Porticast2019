<!DOCTYPE html>
<html>
<head>
	<title> Porticast: Catia Homepage</title>
	<link rel="stylesheet" type = "text/css" href="style.css" />
</head>



<body>

<nav>
	<a href="index.php"> Home </a>

	<a class="selected" href="Catia.php"> Catia </a>

	<a href="Wicklow-Home.php"> Wicklow Street Induction </a>

	<a href="Matlab-Home.php"> Matlab </a>

	<a href="Forum-Home.php"> Forum </a>

</nav>

</body>
</html>