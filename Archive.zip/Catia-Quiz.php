<html>

<head>

	<title> Porticast: Home</title>
	<link rel="stylesheet" type = "text/css" href="style.css?version=1"  />
	<script src="main.js"></script>

</head>

<body>

	

	






	<h1> Question 1. In what order should you make an omelette? </h1>
	<br>
	<input id="start" type="button" value="Go" onclick="go();"> 
	<div id="TimedQuestion">
	<form id="Questions">
	</form>
	</div>
	<br>
	<input id="Finish" type="button" value = "Finito" onclick="check();">
	<input id="Reset" type="button" value = "Reset" onclick="reset()">

	<p id="TotalCorrect"></p>
	<p id="demo"></p>


	<footer>
	</footer>

</body>

</html>