<?php
$title= "Catia Getting Started";
require_once 'headerTEST.php' ;
?>


<!DOCTYPE html>
<html>
<head>
	<title>Porticast Body</title>
	<link rel="stylesheet" type="text/css" href="Stylesheets\wicklow_style.css">
</head>
<body>
	<div class="Headers">
		<h2 id="main">
			Workshop Tools
		</h2>
		<br>
	</div>
	<div class="episode">
		<h3 id="pillar">
			Pillar Drill:
		</h3>
		<div class="content">
			<div class="video">
				<iframe width="100%" src="https://www.youtube.com/embed/MtN1YnoL46Q" frameborder="0" allow="accelerometer;  autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
			<div class="text">
				<p>
					This is the placeholder for the text concerning the pillar drill video. This is the placeholder for the text concerning the pillar drill video. This is the placeholder for the text concerning the pillar drill video.


				Testing testing testing</p>
			</div>
		</div>
	</div>
	<div class="episode">
			<h3 id="cord">
				Cordless Drill
			</h3>
			<div class="content">
					<div class="video">
				<iframe width="100%" src="https://www.youtube.com/embed/MtN1YnoL46Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
			<div class="text">
				<p>
					This is the placeholder for the text concerning the pillar drill video. This is the placeholder for the text concerning the pillar drill video. This is the placeholder for the text concerning the pillar drill video.</p>
			</div>
			</div>
	</div>
	<div class="episode">
			<h3 id="cord">
				Glue Gun
			</h3>
			<div class="content">
					<div class="video">
				<iframe width="100%" src="https://www.youtube.com/embed/MtN1YnoL46Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
			<div class="text">
				<p>
					This is the placeholder for the text concerning the pillar drill video. This is the placeholder for the text concerning the pillar drill video. This is the placeholder for the text concerning the pillar drill video.</p>
			</div>
			</div>
	</div>
		<div class="episode">
			<h3 id="cord">
				Dremel
			</h3>
			<div class="content">
					<div class="video">
				<iframe width="100%" src="https://www.youtube.com/embed/MtN1YnoL46Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
			<div class="text">
				<p>
					This is the placeholder for the text concerning the pillar drill video. This is the placeholder for the text concerning the pillar drill video. This is the placeholder for the text concerning the pillar drill video.</p>
			</div>
			</div>
	</div>
		<div class="episode">
			<h3 id="cord">
				Soldering Iron
			</h3>
			<div class="content">
					<div class="video">
				<iframe width="100%" src="https://www.youtube.com/embed/MtN1YnoL46Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
			<div class="text">
				<p>
					This is the placeholder for the text concerning the pillar drill video. This is the placeholder for the text concerning the pillar drill video. This is the placeholder for the text concerning the pillar drill video.</p>
			</div>
			</div>
	</div>

</body>
</html>



