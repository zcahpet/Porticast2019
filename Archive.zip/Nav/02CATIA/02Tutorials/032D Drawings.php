<body>
	<div id="background">
	<article>
	<h1>2D Drawings</H1>


<?php
$data = [
['video_title' =>'Angle Bracket 2D - 1','id'=>'cdXQHlWytA0', 'description'=>"Welcome to this video series! This video is about dimensioning the Front View in a CAD Drawing. Here you will learn how to insert basic dimensions, some tolerances and dimension texts. You will also learn how to change the style of lines and tidy up a drawing. Check out the other tutorials and tips on offer too!"],
['video_title' =>'Angle Bracket 2D - 2','id'=>'viLQ8vFG5NQ', 'description'=>"Welcome to this video series! This video is about dimensioning the Front View in a CAD Drawing. Here you will learn how to insert basic dimensions, some tolerances and dimension texts. You will also learn how to change the style of lines and tidy up a drawing. Check out the other tutorials and tips on offer too!"],
['video_title' =>'Angle Bracket 2D - 3','id'=>'8mO_YNsjnwI', 'description'=>"Welcome to this video series! This video is about dimensioning the Auxiliary View in a CAD Drawing. Here you will learn some more tips on tidying up a CAD drawing and how to dimension circular pattern features. Check out the other tutorials and tips on offer too!"],
['video_title' =>'Angle Bracket 2D - 4','id'=>'a71dPUCtGBY', 'description'=>"Welcome to this video series! This video is about dimensioning the Left View in a CAD Drawing. You will learn how to dimension some holes hidden from sight without using the Section View. There will also be some more tips on tidying up a CAD drawing. Check out the other tutorials and tips on offer too!"],
['video_title' =>'Angle Bracket 2D - 5','id'=>'ZAtY47B33Ag', 'description'=>"Welcome to this video series! This video is about creating and dimensioning the Section View in a CAD Drawing. Here you will learn about dimensioning hidden details and threads. There will also be further tips on adding tolerances to holes. Check out the other tutorials and tips on offer too!"],
['video_title' =>'Angle Bracket 2D - 6','id'=>'sU91sYJGrCM', 'description'=>"Welcome to this video series! This video is about dimensioning the Bottom View in a CAD Drawing. Here you will learn how to dimension rectangular pattern features and tidy up CAD drawings using group dimensioning. Check out the other tutorials and tips on offer too!"],
];
create_video_list($data);
?>
		
		
				
		
</article>
</div>
</body>
</html>



