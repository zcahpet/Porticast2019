<body>
	<div id="background">
	<article>
		<h1>Workshop Tools</h1>

<?php
$data = [
['video_title' =>"PPE Do's and Don'ts",'id'=>'2QiNIust0cg', 'description'=>'Welcome to this induction video personal protective equipment.'],
['video_title' =>'Cordless Drill','id'=>'HYWfs7x_p04', 'description'=>'Welcome to this induction video on how to safely use the cordless drill.'],
['video_title' =>'Glue Gun','id'=>'qvpihF6CpuE', 'description'=>'Welcome to this induction video on how to safely use the glue gun.'],
['video_title' =>'Soldering Iron','id'=>'Ip-GeDaAfQk', 'description'=>'Welcome to this induction video on how to safely use the soldering iron.'],
['video_title' =>'Pillar Drill','id'=>'bPAyz0H8maw', 'description'=>'Welcome to this induction video on how to safely use the pillar drill.'],
['video_title' =>'Dremel','id'=>'Gsx7Rk13GY4', 'description'=>'Welcome to this induction video on how to safely use the dremel.'],
];
create_video_list($data);


?>

</article>
</div>
</body>
</html>



