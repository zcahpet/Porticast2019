<body>
	<div id="background">
	<article>			
		<h1>3D Printer and Laser Cutter</h1>

<?php 
$data = [
['video_title' =>'3D Printer: How to print','id'=>'hyiPyaR_pv0', 'description'=>"Welcome to this video series! This tutorial has very basic information about the print studio interface and how to export from CATIA ready for printing."],
['video_title' =>'3D Printer: Parameters','id'=>'t3Ui77G4yBQ', 'description'=>'Welcome to this video series!'],
['video_title' =>'3D Printer: Parameters continued','id'=>'cyIV-5BQ5VM', 'description'=>'Welcome to this video series!'],
['video_title' =>'Using the Laser Cutter','id'=>'QUHAxgWJdLw', 'description'=>'Welcome to this induction video on how to safely use the Laser cutter.'],
];
create_video_list($data);


?>

</article>
</div>
</body>
</html>



