<?php

define("SERVER_ADR", "http://localhost:8888/Porticast2019/");
define ("SERVER_ROOT", $_SERVER['DOCUMENT_ROOT'].'/Porticast2019/'); 


?>