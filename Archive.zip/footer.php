<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="..\..\Stylesheets\footer_style.css">
</head>
<footer id="main2">
	<!--<img src="..\..\Stylesheets\footer.png" id="footer_image" width="100%">-->
		<nav>
			<ul>
				<li><a href="index.html"><b>HOME</b></a></li>
				<li><a href="index.html"><b>MOODLE</b></a></li>
				<li><a href="index.html"><b>SUPPORT</b></a></li>
				<li><a href="index.html"><b>ABOUT</b></a></li>
			</ul>
		</nav>	
	</footer>
</html>


